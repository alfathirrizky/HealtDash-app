import express from "express";
import db from "./db.js";
import cors from "cors";
import { PORT } from "./config/index.js";
import dotenv from "dotenv";
import path from "path";
import uploadRoutes from "./routes/uploadRoutes.js";
import questionRoutes from "./routes/question.js";
import authRoutes from "./routes/auth.js";
import userRoutes from "./routes/user.js";
import answerRoutes from "./routes/answer.js";
import galleryRoutes from "./routes/gallery.js";
import surveyRoutes from "./routes/survey.js";
import SuggestionRoute from "../backend/routes/SuggestionRoute.js"

dotenv.config();
const app = express();

app.use(cors({
  origin: "http://localhost:5173",
  credentials: true,
}));
// Middleware agar bisa membaca JSON dari body request
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files untuk mengakses gambar yang diupload
app.use("/uploads", express.static(path.resolve("uploads")));

// Cek server
app.get("/", (req, res) => {
  res.json({ message: "API berjalan 🚀" });
});

//routes
app.use("/api", uploadRoutes);
// Semua endpoint question diawali /questions
app.use("/api/questions", questionRoutes);
// Semua endpoint user diawali /users
app.use("/api/users", userRoutes);
// Semua endpoint answers diawali /answers
app.use("/api/answers", answerRoutes);
// Semua endpoint auth diawali /auth
app.use("/api/auth", authRoutes);
// Semua endpoint educations diawali /educations
app.use("/api/educations", galleryRoutes);
// Semua endpoint surveys diawali /surveys
app.use("/api/surveys", surveyRoutes);
// Semua endpoint sugestions diawali /suggestions
app.use("/api/suggestions", SuggestionRoute);

// Jalankan server
app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});
